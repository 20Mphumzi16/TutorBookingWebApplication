package za.ac.cput.za.ac.cput.domain;

import java.util.Objects;

public class Subject {
    private Long id;
    private String subjectName;
    private String subjectDescription;
    private int grade;

    public Subject() {
    }
    public Subject(SubjectBuilder builder) {
        this.id = builder.id;
        this.subjectName = builder.subjectName;
        this.subjectDescription = builder.subjectDescription;
        this.grade = builder.grade;
    }

    public Long getId() {
        return id;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public String getSubjectDescription() {
        return subjectDescription;
    }

    public int getGrade() {
        return grade;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Subject subject = (Subject) o;
        return grade == subject.grade && Objects.equals(id, subject.id) && Objects.equals(subjectName, subject.subjectName) && Objects.equals(subjectDescription, subject.subjectDescription);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, subjectName, subjectDescription, grade);
    }

    @Override
    public String toString() {
        return "School{" +
                "id=" + id +
                ", subjectName='" + subjectName + '\'' +
                ", subjectDescription='" + subjectDescription + '\'' +
                ", grade=" + grade +
                '}';
    }

    public static class SubjectBuilder {
        private Long id;
        private String subjectName;
        private String subjectDescription;
        private int grade;
        public SubjectBuilder() {

        }

        public SubjectBuilder setId(Long id) {
            this.id = id;
            return this;
        }

        public SubjectBuilder setName(String subjectName) {
            this.subjectName = subjectName;
            return this;
        }

        public SubjectBuilder setSubjectDescription(String subjectDescription) {
            this.subjectDescription = subjectDescription;
            return this;
        }

        public SubjectBuilder setGrade(int grade) {
            this.grade = grade;
            return this;
        }
        public SubjectBuilder copy(Subject subject) {
            this.id = subject.id;
            this.subjectName = subject.subjectName;
            this.subjectDescription = subject.subjectDescription;
            this.grade = subject.grade;
            return this;
        }
        public Subject build() {
            return new Subject(this);
        }
    }
}
