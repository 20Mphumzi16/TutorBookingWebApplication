package za.ac.cput.domain;

public enum BookingMode {
    ONLINE,ON_CAMPUS
}
