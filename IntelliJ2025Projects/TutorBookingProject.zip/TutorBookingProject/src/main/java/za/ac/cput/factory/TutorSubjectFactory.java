package za.ac.cput.factory;

import za.ac.cput.domain.Subject;
import za.ac.cput.domain.Tutor;
import za.ac.cput.domain.TutorSubject;

public class TutorSubjectFactory {
//    public static TutorSubject TutorSubject(Long id, Tutor tutor, Subject subject,String fromLevel,String toLevel) {
//
//    }
}
