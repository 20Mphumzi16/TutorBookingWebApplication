//package za.ac.cput.factory;
//
//import za.ac.cput.domain.Booking;
//import za.ac.cput.domain.Subject;
//import za.ac.cput.domain.SubjectBooking;
//
//public class SubjectBookingFactory {
//private static SubjectBooking buildSubjectBooking(Long id, Subject subject, Booking booking) {}
//}
