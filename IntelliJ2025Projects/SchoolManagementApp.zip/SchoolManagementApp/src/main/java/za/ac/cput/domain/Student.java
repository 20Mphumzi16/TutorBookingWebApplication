package za.ac.cput.domain;

import java.time.LocalDate;

public class Student {
    private long id;
    private String gender;
    private LocalDate dob;
    private Contact contact;
    private Name name;


    public Student() {
    }
    public Student(StudentBuilder builder) {
        this.id = builder.id;
        this.gender = builder.gender;
        this.dob = builder.dob;
        this.contact = builder.contact;
        this.name = builder.name;
    }

    public long getId() {
        return id;
    }

    public String getGender() {
        return gender;
    }

    public LocalDate getDob() {
        return dob;
    }

    public Contact getContact() {
        return contact;
    }

    public Name getName() {
        return name;
    }


    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", gender='" + gender + '\'' +
                ", dob=" + dob +
                ", contact=" + contact +
                ", name=" + name +
                '}';
    }

    public static class StudentBuilder {
        private long id;
        private String gender;
        private LocalDate dob;
        private Contact contact;
        private Name name;

        public StudentBuilder() {
        }

        public StudentBuilder setId(long id) {
            this.id = id;
            return this;
        }

        public StudentBuilder setGender(String gender) {
            this.gender = gender;
            return this;
        }

        public StudentBuilder setDob(LocalDate dob) {
            this.dob = dob;
            return this;
        }

        public StudentBuilder setContact(Contact contact) {
            this.contact = contact;
            return this;
        }

        public StudentBuilder setName(Name name) {
            this.name = name;
            return this;
        }

        public Student build() {
            return new Student(this)
                    ;
        }
    }
}